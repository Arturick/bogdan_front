import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _28cab631 = () => interopDefault(import('..\\pages\\analyze\\index.vue' /* webpackChunkName: "pages/analyze/index" */))
const _2d74946f = () => interopDefault(import('..\\pages\\buyout\\index.vue' /* webpackChunkName: "pages/buyout/index" */))
const _5751ed0a = () => interopDefault(import('..\\pages\\cheat\\index.vue' /* webpackChunkName: "pages/cheat/index" */))
const _3bd1eb44 = () => interopDefault(import('..\\pages\\competition\\index.vue' /* webpackChunkName: "pages/competition/index" */))
const _1a5f18c3 = () => interopDefault(import('..\\pages\\delivery\\index.vue' /* webpackChunkName: "pages/delivery/index" */))
const _0e1cc5a1 = () => interopDefault(import('..\\pages\\map\\index.vue' /* webpackChunkName: "pages/map/index" */))
const _3db42704 = () => interopDefault(import('..\\pages\\news\\index.vue' /* webpackChunkName: "pages/news/index" */))
const _561ecf93 = () => interopDefault(import('..\\pages\\positions\\index.vue' /* webpackChunkName: "pages/positions/index" */))
const _f8af1288 = () => interopDefault(import('..\\pages\\ransoms\\index.vue' /* webpackChunkName: "pages/ransoms/index" */))
const _4d348bde = () => interopDefault(import('..\\pages\\reports\\index.vue' /* webpackChunkName: "pages/reports/index" */))
const _627dcffc = () => interopDefault(import('..\\pages\\reviews\\index.vue' /* webpackChunkName: "pages/reviews/index" */))
const _4a4a499e = () => interopDefault(import('..\\pages\\sales\\index.vue' /* webpackChunkName: "pages/sales/index" */))
const _cbbf7064 = () => interopDefault(import('..\\pages\\tariffs\\index.vue' /* webpackChunkName: "pages/tariffs/index" */))
const _47d59d64 = () => interopDefault(import('..\\pages\\Ueconomy\\index.vue' /* webpackChunkName: "pages/Ueconomy/index" */))
const _3fecfb0c = () => interopDefault(import('..\\pages\\user\\index.vue' /* webpackChunkName: "pages/user/index" */))
const _26a34252 = () => interopDefault(import('..\\pages\\analyze\\analyze2.vue' /* webpackChunkName: "pages/analyze/analyze2" */))
const _de49f6c6 = () => interopDefault(import('..\\pages\\buyout\\Onkey.vue' /* webpackChunkName: "pages/buyout/Onkey" */))
const _37353266 = () => interopDefault(import('..\\pages\\buyout\\plan\\index.vue' /* webpackChunkName: "pages/buyout/plan/index" */))
const _03dc7766 = () => interopDefault(import('..\\pages\\buyout\\properties.vue' /* webpackChunkName: "pages/buyout/properties" */))
const _044df27d = () => interopDefault(import('..\\pages\\cheat\\cheat_1.vue' /* webpackChunkName: "pages/cheat/cheat_1" */))
const _045c09fe = () => interopDefault(import('..\\pages\\cheat\\cheat_2.vue' /* webpackChunkName: "pages/cheat/cheat_2" */))
const _046a217f = () => interopDefault(import('..\\pages\\cheat\\cheat_3.vue' /* webpackChunkName: "pages/cheat/cheat_3" */))
const _e4d61612 = () => interopDefault(import('..\\pages\\competition\\competition2.vue' /* webpackChunkName: "pages/competition/competition2" */))
const _91430d06 = () => interopDefault(import('..\\pages\\ransoms\\ransoms_1.vue' /* webpackChunkName: "pages/ransoms/ransoms_1" */))
const _9126de04 = () => interopDefault(import('..\\pages\\ransoms\\ransoms_2.vue' /* webpackChunkName: "pages/ransoms/ransoms_2" */))
const _910aaf02 = () => interopDefault(import('..\\pages\\ransoms\\ransoms_3.vue' /* webpackChunkName: "pages/ransoms/ransoms_3" */))
const _90ee8000 = () => interopDefault(import('..\\pages\\ransoms\\ransoms_4.vue' /* webpackChunkName: "pages/ransoms/ransoms_4" */))
const _90d250fe = () => interopDefault(import('..\\pages\\ransoms\\ransoms_5.vue' /* webpackChunkName: "pages/ransoms/ransoms_5" */))
const _90b621fc = () => interopDefault(import('..\\pages\\ransoms\\ransoms_6.vue' /* webpackChunkName: "pages/ransoms/ransoms_6" */))
const _9099f2fa = () => interopDefault(import('..\\pages\\ransoms\\ransoms_7.vue' /* webpackChunkName: "pages/ransoms/ransoms_7" */))
const _cc6a34ec = () => interopDefault(import('..\\pages\\reports\\report_1.vue' /* webpackChunkName: "pages/reports/report_1" */))
const _cc4e05ea = () => interopDefault(import('..\\pages\\reports\\report_2.vue' /* webpackChunkName: "pages/reports/report_2" */))
const _cc31d6e8 = () => interopDefault(import('..\\pages\\reports\\report_3.vue' /* webpackChunkName: "pages/reports/report_3" */))
const _cc15a7e6 = () => interopDefault(import('..\\pages\\reports\\report_4.vue' /* webpackChunkName: "pages/reports/report_4" */))
const _8b03af52 = () => interopDefault(import('..\\pages\\sales\\sales2.vue' /* webpackChunkName: "pages/sales/sales2" */))
const _8ae78050 = () => interopDefault(import('..\\pages\\sales\\sales3.vue' /* webpackChunkName: "pages/sales/sales3" */))
const _63c66943 = () => interopDefault(import('..\\pages\\Ueconomy\\ue-sales.vue' /* webpackChunkName: "pages/Ueconomy/ue-sales" */))
const _09949e23 = () => interopDefault(import('..\\pages\\user\\login.vue' /* webpackChunkName: "pages/user/login" */))
const _573588c8 = () => interopDefault(import('..\\pages\\buyout\\plan\\_group.vue' /* webpackChunkName: "pages/buyout/plan/_group" */))
const _567820df = () => interopDefault(import('..\\pages\\delivery\\_group.vue' /* webpackChunkName: "pages/delivery/_group" */))
const _2e560980 = () => interopDefault(import('..\\pages\\reviews\\_group.vue' /* webpackChunkName: "pages/reviews/_group" */))
const _54569cf7 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/analyze",
    component: _28cab631,
    name: "analyze"
  }, {
    path: "/buyout",
    component: _2d74946f,
    name: "buyout"
  }, {
    path: "/cheat",
    component: _5751ed0a,
    name: "cheat"
  }, {
    path: "/competition",
    component: _3bd1eb44,
    name: "competition"
  }, {
    path: "/delivery",
    component: _1a5f18c3,
    name: "delivery"
  }, {
    path: "/map",
    component: _0e1cc5a1,
    name: "map"
  }, {
    path: "/news",
    component: _3db42704,
    name: "news"
  }, {
    path: "/positions",
    component: _561ecf93,
    name: "positions"
  }, {
    path: "/ransoms",
    component: _f8af1288,
    name: "ransoms"
  }, {
    path: "/reports",
    component: _4d348bde,
    name: "reports"
  }, {
    path: "/reviews",
    component: _627dcffc,
    name: "reviews"
  }, {
    path: "/sales",
    component: _4a4a499e,
    name: "sales"
  }, {
    path: "/tariffs",
    component: _cbbf7064,
    name: "tariffs"
  }, {
    path: "/Ueconomy",
    component: _47d59d64,
    name: "Ueconomy"
  }, {
    path: "/user",
    component: _3fecfb0c,
    name: "user"
  }, {
    path: "/analyze/analyze2",
    component: _26a34252,
    name: "analyze-analyze2"
  }, {
    path: "/buyout/Onkey",
    component: _de49f6c6,
    name: "buyout-Onkey"
  }, {
    path: "/buyout/plan",
    component: _37353266,
    name: "buyout-plan"
  }, {
    path: "/buyout/properties",
    component: _03dc7766,
    name: "buyout-properties"
  }, {
    path: "/cheat/cheat_1",
    component: _044df27d,
    name: "cheat-cheat_1"
  }, {
    path: "/cheat/cheat_2",
    component: _045c09fe,
    name: "cheat-cheat_2"
  }, {
    path: "/cheat/cheat_3",
    component: _046a217f,
    name: "cheat-cheat_3"
  }, {
    path: "/competition/competition2",
    component: _e4d61612,
    name: "competition-competition2"
  }, {
    path: "/ransoms/ransoms_1",
    component: _91430d06,
    name: "ransoms-ransoms_1"
  }, {
    path: "/ransoms/ransoms_2",
    component: _9126de04,
    name: "ransoms-ransoms_2"
  }, {
    path: "/ransoms/ransoms_3",
    component: _910aaf02,
    name: "ransoms-ransoms_3"
  }, {
    path: "/ransoms/ransoms_4",
    component: _90ee8000,
    name: "ransoms-ransoms_4"
  }, {
    path: "/ransoms/ransoms_5",
    component: _90d250fe,
    name: "ransoms-ransoms_5"
  }, {
    path: "/ransoms/ransoms_6",
    component: _90b621fc,
    name: "ransoms-ransoms_6"
  }, {
    path: "/ransoms/ransoms_7",
    component: _9099f2fa,
    name: "ransoms-ransoms_7"
  }, {
    path: "/reports/report_1",
    component: _cc6a34ec,
    name: "reports-report_1"
  }, {
    path: "/reports/report_2",
    component: _cc4e05ea,
    name: "reports-report_2"
  }, {
    path: "/reports/report_3",
    component: _cc31d6e8,
    name: "reports-report_3"
  }, {
    path: "/reports/report_4",
    component: _cc15a7e6,
    name: "reports-report_4"
  }, {
    path: "/sales/sales2",
    component: _8b03af52,
    name: "sales-sales2"
  }, {
    path: "/sales/sales3",
    component: _8ae78050,
    name: "sales-sales3"
  }, {
    path: "/Ueconomy/ue-sales",
    component: _63c66943,
    name: "Ueconomy-ue-sales"
  }, {
    path: "/user/login",
    component: _09949e23,
    name: "user-login"
  }, {
    path: "/buyout/plan/:group",
    component: _573588c8,
    name: "buyout-plan-group"
  }, {
    path: "/delivery/:group",
    component: _567820df,
    name: "delivery-group"
  }, {
    path: "/reviews/:group",
    component: _2e560980,
    name: "reviews-group"
  }, {
    path: "/",
    component: _54569cf7,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
