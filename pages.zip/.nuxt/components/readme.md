# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<AppMap>` | `<app-map>` (components/AppMap.vue)
- `<Breadcrumbs>` | `<breadcrumbs>` (components/Breadcrumbs.vue)
- `<Button>` | `<button>` (components/Button.vue)
- `<Checkbox>` | `<checkbox>` (components/Checkbox.vue)
- `<Modal>` | `<modal>` (components/Modal.vue)
- `<Select>` | `<select>` (components/Select.vue)
- `<Switcher>` | `<switcher>` (components/Switcher.vue)
- `<TheFooter>` | `<the-footer>` (components/TheFooter.vue)
- `<TheHeader>` | `<the-header>` (components/TheHeader.vue)
- `<Upline>` | `<upline>` (components/Upline.vue)
- `<ChartReport>` | `<chart-report>` (components/chart/ChartReport.vue)
- `<ChartReportShort>` | `<chart-report-short>` (components/chart/ChartReportShort.vue)
- `<ChartSale>` | `<chart-sale>` (components/chart/ChartSale.vue)
- `<CommonTable>` | `<common-table>` (components/common/Table.vue)
- `<MainFastinfo>` | `<main-fastinfo>` (components/main/Fastinfo.vue)
- `<MainNotices>` | `<main-notices>` (components/main/Notices.vue)
- `<MainReports>` | `<main-reports>` (components/main/Reports.vue)
- `<MainStat>` | `<main-stat>` (components/main/Stat.vue)
- `<MainWeekChart>` | `<main-week-chart>` (components/main/WeekChart.vue)
