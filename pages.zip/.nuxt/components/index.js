export { default as AppMap } from '../..\\components\\AppMap.vue'
export { default as Breadcrumbs } from '../..\\components\\Breadcrumbs.vue'
export { default as Button } from '../..\\components\\Button.vue'
export { default as Checkbox } from '../..\\components\\Checkbox.vue'
export { default as Modal } from '../..\\components\\Modal.vue'
export { default as Select } from '../..\\components\\Select.vue'
export { default as Switcher } from '../..\\components\\Switcher.vue'
export { default as TheFooter } from '../..\\components\\TheFooter.vue'
export { default as TheHeader } from '../..\\components\\TheHeader.vue'
export { default as Upline } from '../..\\components\\Upline.vue'
export { default as ChartReport } from '../..\\components\\chart\\ChartReport.vue'
export { default as ChartReportShort } from '../..\\components\\chart\\ChartReportShort.vue'
export { default as ChartSale } from '../..\\components\\chart\\ChartSale.vue'
export { default as CommonTable } from '../..\\components\\common\\Table.vue'
export { default as MainFastinfo } from '../..\\components\\main\\Fastinfo.vue'
export { default as MainNotices } from '../..\\components\\main\\Notices.vue'
export { default as MainReports } from '../..\\components\\main\\Reports.vue'
export { default as MainStat } from '../..\\components\\main\\Stat.vue'
export { default as MainWeekChart } from '../..\\components\\main\\WeekChart.vue'

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
