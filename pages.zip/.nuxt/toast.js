import { createToastInterface } from "vue-toastification";

export default function (ctx, inject) {
  const toast = createToastInterface({"cssFile":"D:\\js\\bogdan_verst\\node_modules\\vue-toastification\\dist\\index.css","timeout":2000,"closeOnClick":false});
  inject('toast', toast);
}
