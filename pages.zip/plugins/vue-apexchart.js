import Vue from 'vue'
import VueApexCharts from 'vue-apexcharts'

Vue.component('VueApexCharts', VueApexCharts);