<template>
	<v-app >
		<div class="rate-app rate-app_login">
			<Nuxt class="relative z-10"/>
		</div>
	</v-app>
</template>