<template>
    <div class="md:container md:mx-auto">
        <div class="bg-white rounded-3xl mt-2.5 mx-2.5 p-7 pb-20">
            <div class="l1_sales">
                <NuxtLink to="/">
                    <div class="btn_more_a">Назад</div>
                </NuxtLink>
                <div class="win_title_s">
                    <span>Главная /</span> Продажи
                </div>
            </div>
            <div class="u_titles">
                <div class="u_txt">
                    <div class="u_title">Анализ товара artikul_12941529</div>
                    <div class="u_sup">
                        В данном разделе вы можете увидеть свой анализ продаж,<br> есть возможные сортировки, за сегодня, за вчера, за 7<br>  дней, за неделю, за месяц
                    </div>
                </div>
                <div class="btn_u">
                    Выгрузить в Excel
                </div>
            </div>
            <div class="title_ues">Продажи товара artikul_12941529</div>
            <div class="sales_params">
                <div class="today">За сегодня</div>
                <div class="yesterday">Вчера</div>
                <div class="week">7 дней</div>
                <div class="month">Месяц</div>
            </div>
            <div class="table_stat_ues">
                <div class="l1_st_ues">
                    <div>Товар</div>
                    <div>Продажи</div>
                    <div>Возвраты</div>
                    <div>Логистика</div>
                    <div>Комиссия</div>
                    <div>Статьи расходов</div>
                    <div>Прибыль</div>
                    <div>ABC анализ</div>
                    <div>Цена</div>
                </div>
                <div class="l2_st_ues">
                    <div class="bl_pr_ues">
                        <span>Фото</span>
                        <span>Бренд</span>
                        <span>Артикул поставщика</span>
                        <span>Баркод</span>
                        <span>SKU</span>
                        <span>Размер</span>
                        <span>Категория</span>
                        <span>Себестоимость товаров</span>
                    </div>
                    <div class="bl_sales_ues">
                        <span>Сумма</span>
                        <span>Кол - во</span>
                        <span>За вычетом возвратов</span>
                    </div>
                    <div class="bl_returns_ues">
                        <span>Сумма</span>
                        <span>Кол-во</span>
                    </div>
                    <div class="bl_log_ues">
                        <span>К клиенту</span>
                        <span>От клиента</span>
                    </div>
                    <div class="bl_com_ues">
                        <span>Штрафы</span>
                        <span>Комиссия WB</span>
                    </div>
                    <div class="bl_exp_ues">
                        <span></span>
                    </div>
                    <div class="bl_prof_ues">
                        <span>Маржинальная прибыль</span>
                        <span>Рентабельность реализованной продукции</span>
                        <span>Маржинальность</span>
                    </div>
                    <div class="bl_anal_ues">
                        <span></span>
                    </div>
                    <div class="bl_price_ues">
                        <span>Базовая</span>
                        <span>Скидка</span>
                        <span>Цена со скидкой</span>
                    </div>
                </div>
                <div class="l3_st_ues">
                    <div class="bl_pr_ues">
                        <span>
                            <img src="../../assets/images/pr_img.svg" alt="">
                        </span>
                        <span>BRAND</span>
                        <span>artikul_12941529</span>
                        <span>7885821511582</span>
                        <span>78858215</span>
                        <span>S</span>
                        <span>Категория товаров</span>
                        <span></span>
                    </div>
                    <div class="bl_sales_ues">
                        <span>110 000р</span>
                        <span>10</span>
                        <span>90 000</span>
                    </div>
                    <div class="bl_returns_ues">
                        <span>20 000</span>
                        <span>2</span>
                    </div>
                    <div class="bl_log_ues">
                        <span>150р</span>
                        <span>210р</span>
                    </div>
                    <div class="bl_com_ues">
                        <span>0р</span>
                        <span>1000р</span>
                    </div>
                    <div class="bl_exp_ues">
                        <span>-1500р</span>
                    </div>
                    <div class="bl_prof_ues">
                        <span>50000р</span>
                        <span>50000р</span>
                        <span>50%</span>
                    </div>
                    <div class="bl_anal_ues">
                        <span>A кат</span>
                    </div>
                    <div class="bl_price_ues">
                        <span>15 000р</span>
                        <span>25%</span>
                        <span>10 000р</span>
                    </div>
                </div>
            </div>
            <div class="txt_ues">
                Общее количество:  &nbsp;<span>1 артикула, 9 шт</span><br>  
                Сумма продаж:  &nbsp;<span>110 000₽</span><br>  
                Возвраты: &nbsp;<span>20 000Р</span><br>  
                Комиссия: &nbsp;<span>1000р</span><br>   
                Логистика к клиенту и от клиента: &nbsp;<span>360р</span><br>  
                Себестоимость товаров: &nbsp;<span>N рублей</span><br>  
                Прочие статьи расходов: &nbsp;<span>30 000 р</span><br>  
                <span>Итого: 60 00р</span><br> 
                <span>ПРИБЫЛЬ С ТОВРАРА: 50 000р</span>
            </div>
        </div>
    </div>
</template>