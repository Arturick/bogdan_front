<template>
    <section class="content">
        <div class="wrap content__wrap">
            <div class="content__group content__group_1">
                <div class="positions content-box">
                    <div class="positions__group positions__group_0">
                        <div class="content-action">
                            <div>
                                <nuxt-link to="/" class="but but_3">Назад</nuxt-link>
                            </div>
                            <ul class="breadcrumbs">
                                <li class="breadcrumbs__item">
                                    <nuxt-link to="/" class="breadcrumbs__link">Главная</nuxt-link>
                                </li>
                                <li class="breadcrumbs__item">
                                    Позиции товара в выдаче
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="positions__group positions__group_1">
                        <div class="content-title">Позиции товара в выдаче</div>
                    </div>
                    <div class="positions__group positions__group_2">
                        <div class="positions-table">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Фото</th>
                                        <th>Артикул</th>
                                        <th>Запрос</th>
                                        <th>Товаров на WB</th>
                                        <th>04.07</th>
                                        <th>05.07</th>
                                        <th>06.07</th>
                                        <th>06.07</th>
                                        <th>06.07</th>
                                        <th>06.07</th>
                                        <th>06.07</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><img :src="require(`assets/images/17849231-1.png`)" alt=""></td>
                                        <td>78858215</td>
                                        <td>Футболка женская</td>
                                        <td>55 492</td>
                                        <td>150</td>
                                        <td>77</td>
                                        <td>50</td>
                                        <td>50</td>
                                        <td>50</td>
                                        <td>50</td>
                                        <td>50</td>
                                        <td><img :src="require(`/assets/images/close.png`)" alt=""></td>
                                    </tr>
                                    <tr>
                                        <td><img :src="require(`assets/images/17849231-1.png`)" alt=""></td>
                                        <td>78858215</td>
                                        <td>Футболка оверсайз</td>
                                        <td>55 492</td>
                                        <td>150</td>
                                        <td>77</td>
                                        <td>50</td>
                                        <td>50</td>
                                        <td>50</td>
                                        <td>50</td>
                                        <td>50</td>
                                        <td><img :src="require(`assets/images/close.png`)" alt=""></td>
                                    </tr>
                                    <tr>
                                        <td><img :src="require(`assets/images/17849231-1.png`)" alt=""></td>
                                        <td>78858215</td>
                                        <td>Футболка</td>
                                        <td>55 492</td>
                                        <td>150</td>
                                        <td>77</td>
                                        <td>50</td>
                                        <td>50</td>
                                        <td>50</td>
                                        <td>50</td>
                                        <td>50</td>
                                        <td><img :src="require(`/assets/images/close.png`)" alt=""></td>
                                    </tr>
                                    <tr>
                                        <td><img :src="require(`assets/images/17849231-1.png`)" alt=""></td>
                                        <td>78858215</td>
                                        <td>Футболка женская овер</td>
                                        <td>55 492</td>
                                        <td>150</td>
                                        <td>77</td>
                                        <td>50</td>
                                        <td>50</td>
                                        <td>50</td>
                                        <td>50</td>
                                        <td>50</td>
                                        <td><img :src="require(`/assets/images/close.png`)" alt=""></td>
                                    </tr>
                                    <tr>
                                        <td><img :src="require(`assets/images/17849231-1.png`)" alt=""></td>
                                        <td>78858215</td>
                                        <td>Футболка женская</td>
                                        <td>55 492</td>
                                        <td>150</td>
                                        <td>77</td>
                                        <td>50</td>
                                        <td>50</td>
                                        <td>50</td>
                                        <td>50</td>
                                        <td>50</td>
                                        <td><img :src="require(`/assets/images/close.png`)" alt=""></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>

<script>

</script>