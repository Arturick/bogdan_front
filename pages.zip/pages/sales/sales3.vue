<template>
    <div class="md:container md:mx-auto">
        <div class="bg-white rounded-3xl mt-2.5 mx-2.5 p-7 pb-20">
            <div class="l1_sales">
                <div class="btn_more_a">Назад</div>
                <div class="win_title_s"><span>Главная /</span> Продажи и возвраты
                </div>
            </div>
            <div class="l2_sales">
                <div class="l2_title_btn">
                    <div class="sales_title">Продажи товаров</div>
                    <div class="btn_more_a">Выгрузить Excel</div>
                </div>
                <div class="sales_params">
                    <div class="today">За сегодня</div>
                    <div class="yesterday">Вчера</div>
                    <div class="week">7 дней</div>
                    <div class="month">Месяц</div>
                </div>
                <div class="sales_sup">В данном разделе вы можете увидеть свой анализ продаж,<br> есть возможные сортировки, за сегодня, за вчера, за 7<br>дней, за неделю, за месяц
                </div>
                <div class="table_sales">
                    <div class="table_sales_params">
                        <div class="p_brand">Бренд</div>
                        <div class="p_date">Дата</div>
                        <div class="p_img">Фото</div>
                        <div class="p_name">Наименование</div>
                        <div class="p_art">Артикул</div>
                        <div class="p_count">Продано(шт)</div>
                        <div class="p_sale">Скидка</div>
                        <div class="p_price">Логистика к  клиенту (руб)</div>
                        <div class="p_bad">Штрафы</div>
                        <div class="p_commis">Комиссия</div>
                    </div>
                    <div class="table_info">
                        <div class="table_inner">
                            <div class="line_info_sales">
                                <div class="i_brand">Nenaglyada</div>
                                <div class="i_date">33.03.2033</div>
                                <div class="i_img">
                                    <img src="../../assets/images/pr_img.svg" alt="">
                                </div>
                                <div class="i_name">Футболка женская оверсайз....</div>
                                <div class="i_art">12312312312</div>
                                <div class="i_count">3 шт</div>
                                <div class="i_sale">30%</div>
                                <div class="i_price">1 350 руб</div>
                                <div class="i_bad">1200 руб</div>
                                <div class="i_commis">1200 руб</div>
                            </div>
                            <div class="line_info_sales">
                                <div class="i_brand">Nenaglyada</div>
                                <div class="i_date">33.03.2033</div>
                                <div class="i_img">
                                    <img src="../../assets/images/pr_img.svg" alt="">
                                </div>
                                <div class="i_name">Футболка женская оверсайз....</div>
                                <div class="i_art">12312312312</div>
                                <div class="i_count">3 шт</div>
                                <div class="i_sale">30%</div>
                                <div class="i_price">1 350 руб</div>
                                <div class="i_bad">1200 руб</div>
                                <div class="i_commis">1200 руб</div>
                            </div>
                            <div class="line_info_sales">
                                <div class="i_brand">Nenaglyada</div>
                                <div class="i_date">33.03.2033</div>
                                <div class="i_img">
                                    <img src="../../assets/images/pr_img.svg" alt="">
                                </div>
                                <div class="i_name">Футболка женская оверсайз....</div>
                                <div class="i_art">12312312312</div>
                                <div class="i_count">3 шт</div>
                                <div class="i_sale">30%</div>
                                <div class="i_price">1 350 руб</div>
                                <div class="i_bad">1200 руб</div>
                                <div class="i_commis">1200 руб</div>
                            </div>
                            <div class="line_info_sales">
                                <div class="i_brand">Nenaglyada</div>
                                <div class="i_date">33.03.2033</div>
                                <div class="i_img">
                                    <img src="../../assets/images/pr_img.svg" alt="">
                                </div>
                                <div class="i_name">Футболка женская оверсайз....</div>
                                <div class="i_art">12312312312</div>
                                <div class="i_count">3 шт</div>
                                <div class="i_sale">30%</div>
                                <div class="i_price">1 350 руб</div>
                                <div class="i_bad">1200 руб</div>
                                <div class="i_commis">1200 руб</div>
                            </div>
                            <div class="line_info_sales">
                                <div class="i_brand">Nenaglyada</div>
                                <div class="i_date">33.03.2033</div>
                                <div class="i_img">
                                    <img src="../../assets/images/pr_img.svg" alt="">
                                </div>
                                <div class="i_name">Футболка женская оверсайз....</div>
                                <div class="i_art">12312312312</div>
                                <div class="i_count">3 шт</div>
                                <div class="i_sale">30%</div>
                                <div class="i_price">1 350 руб</div>
                                <div class="i_bad">1200 руб</div>
                                <div class="i_commis">1200 руб</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
</template>
