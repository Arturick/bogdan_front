<template>
    <div class="md:container md:mx-auto">
        <div class="bg-white rounded-3xl mt-2.5 mx-2.5 p-7 pb-20">
            <div class="l1_sales">
                <NuxtLink to="/">
                    <div class="btn_more_a">Назад</div>
                </NuxtLink>
                <div class="win_title_s">
                    <NuxtLink to="/competition"><span>Главная /</span></NuxtLink> Конкуренция
                </div>
            </div>
            <div class="sales_title">Сравните свои товары</div>
            <div class="comp_sup">В данном разделе вы можете 4 сравнить свои товары с<br> товарами конкурентов (по цене, по позициям в выдаче и<br>  отображению в ключевых запросах).
            </div>
            <div class="yPr_title">Ваш товар</div>
            <div class="yPr_block">
                <img src="../../assets/images/pr_img.svg" alt="">
                <div class="yPr_txt">
                    <span>Продавец: ИП Михалюк Н. С.</span>
                    <span>SKU: 78858215</span>
                    <span>Бренд: Nenaglyada</span>
                    <span>Тип продаж: FBS</span>
                </div>
            </div>
                <div class="table_c2">
                    <div class="table_cont_md">
                        <div class="tcomp_con">
                            <div class="tc2_params">
                                <span>Бренд</span>
                                <span>Фото</span>
                                <span>Артикул</span>
                                <span>Цена</span>
                                <span>Запрос</span>
                                <span>Частотность WB</span>
                                <span>Товаров на WB</span>
                                <span>25.07</span>
                            </div>
                            <div class="tablec2">
                                <div class="table_c2_inner">
                                    <div class="table_c2_line">
                                        <div>
                                            <img src="../../assets/images/logo_brand.svg" alt="">
                                        </div>
                                        <div>
                                            <img src="../../assets/images/pr_img.svg" alt="">
                                        </div>
                                        <div>78858215</div>
                                        <div>271 ₽</div>
                                        <div>Футболка женская</div>
                                        <div>150</div>
                                        <div>150</div>
                                        <div>77</div>
                                    </div>
                                    <div class="table_c2_line">
                                        <div></div>
                                        <div></div>
                                        <div></div>
                                        <div></div>
                                        <div>Футболка оверсайз</div>
                                        <div>150</div>
                                        <div>150</div>
                                        <div>77</div>
                                    </div>
                                    <div class="table_c2_line">
                                        <div>
                                            
                                        </div>
                                        <div>
                                            
                                        </div>
                                        <div></div>
                                        <div></div>
                                        <div>Футболка женская оверсайз</div>
                                        <div>150</div>
                                        <div>150</div>
                                        <div>77</div>
                                    </div>
                                    <div class="table_c2_line">
                                        <div></div>
                                        <div></div>
                                        <div></div>
                                        <div></div>
                                        <div>Футболка женская</div>
                                        <div>150</div>
                                        <div>150</div>
                                        <div>77</div>
                                    </div>
                                    <div class="table_c2_line">
                                        <div>
                                        </div>
                                        <div>
                                        </div>
                                        <div></div>
                                        <div></div>
                                        <div>Футболка женская</div>
                                        <div>150</div>
                                        <div>150</div>
                                        <div>77</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="table_c3">
                        <div class="yPr_title">Ваш товар</div>
                        <div class="yPr_block">
                            <img src="../../assets/images/pr_img.svg" alt="">
                            <div class="yPr_txt">
                                <span>Продавец: ИП Михалюк Н. С.</span>
                                <span>SKU: 78858215</span>
                                <span>Бренд: Nenaglyada</span>
                                <span>Тип продаж: FBS</span>
                            </div>
                        </div>
                    <div class="table_c2">
                        <div class="tcomp_con">
                            <div class="tc2_params">
                                <span>Бренд</span>
                                <span>Фото</span>
                                <span>Артикул</span>
                                <span>Цена</span>
                                <span>Запрос</span>
                                <span>Частотность WB</span>
                                <span>Товаров на WB</span>
                                <span>25.07</span>
                            </div>
                            <div class="tablec2">
                                <div class="table_c2_inner">
                                    <div class="table_c2_line">
                                        <div>
                                            <img src="../../assets/images/logo_brand.svg" alt="">
                                        </div>
                                        <div>
                                            <img src="../../assets/images/pr_img.svg" alt="">
                                        </div>
                                        <div>78858215</div>
                                        <div>271 ₽</div>
                                        <div>Футболка женская</div>
                                        <div>150</div>
                                        <div>150</div>
                                        <div>78</div>
                                    </div>
                                    <div class="table_c2_line">
                                        <div></div>
                                        <div></div>
                                        <div></div>
                                        <div></div>
                                        <div>Футболка оверсайз</div>
                                        <div>150</div>
                                        <div>150</div>
                                        <div>78</div>
                                    </div>
                                    <div class="table_c2_line">
                                        <div>
                                            
                                        </div>
                                        <div>
                                            
                                        </div>
                                        <div></div>
                                        <div></div>
                                        <div>Футболка женская оверсайз</div>
                                        <div>150</div>
                                        <div>150</div>
                                        <div>78</div>
                                    </div>
                                    <div class="table_c2_line">
                                        <div></div>
                                        <div></div>
                                        <div></div>
                                        <div></div>
                                        <div>Футболка женская</div>
                                        <div>150</div>
                                        <div>150</div>
                                        <div>78</div>
                                    </div>
                                    <div class="table_c2_line">
                                        <div>
                                        </div>
                                        <div>
                                        </div>
                                        <div></div>
                                        <div></div>
                                        <div>Футболка женская</div>
                                        <div>150</div>
                                        <div>150</div>
                                        <div>78</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="new_c2_title">Отличия и рекомендации</div>
                <div class="new_c2_sup">Ваш тоавар по высокочастотным ключевым запросам находиться, выше, Но имеет меньше ключевых<br> слов чем у вашего конкурента, но цена у вашего конкурента ниже. остаток, у вас больше, но ваш<br>  конкурент, торгует по FBO.
                </div>
                <div class="new_c2_sup">
                    Мы рекомендовали бы, отгрузить товары на FBO и по работать с ценой. Для более детально аналите,<br>  обратитесь к нашему менеджеру.
                </div>
                </div>
        <div class="down_btn_c3">
                <div class="btn_more_a">Заполнить форму</div>
            </div>
        </div>
        <div class="modal1">
            <div class="modal_content1">
                <div class="modal_content1_inner">
                    <div class="close_md_in">
                        <span class="close_md">&#215;</span>
                    </div>
                    <div class="md1_title">Выберите товар</div>
                    <div class="md_inBtn">
                        <input type="text" class="md1_input" placeholder="Поиск по баркоду, артикулу поставщика, бренду">
                        <div class="btn_more_a">Выбрать</div>
                    </div>
                    <div class="table_md">
                        <div class="tmd_params">
                            <span>Фото</span>
                            <span>Бренд</span>
                            <span>Артикул</span>
                            <span>Размер</span>
                            <span>Баркод</span>
                            <span>Артикул поставщика</span>
                            <span>Цена WB</span>
                        </div>
                        <div class="tmd_lines">
                            <div class="tmd_line">
                                <span><input type="checkbox"></span>
                                <div class="tmd_line_inner">
                                    <span>
                                        <img src="../../assets/images/pr_img.svg" alt="">
                                    </span>
                                    <span>BRAND</span>
                                    <span>78858215</span>
                                    <span>S</span>
                                    <span>7885821511582</span>
                                    <span>artikul_12941529</span>
                                    <span>271 ₽</span>
                                </div>
                            </div>
                            <div class="tmd_line">
                                <span><input type="checkbox"></span>
                                <div class="tmd_line_inner">
                                    <span>
                                        <img src="../../assets/images/pr_img2.svg" alt="">
                                    </span>
                                    <span>BRAND</span>
                                    <span>78858215</span>
                                    <span>XS</span>
                                    <span>7885821511582</span>
                                    <span>artikul_12941529</span>
                                    <span>271 ₽</span>
                                </div>
                            </div>
                            <div class="tmd_line">
                                <span><input type="checkbox"></span>
                                <div class="tmd_line_inner">
                                    <span>
                                        <img src="../../assets/images/pr_img.svg" alt="">
                                    </span>
                                    <span>BRAND</span>
                                    <span>78858215</span>
                                    <span>L</span>
                                    <span>7885821511582</span>
                                    <span>artikul_12941529</span>
                                    <span>271 ₽</span>
                                </div>
                            </div>
                            <div class="tmd_line">
                                <span><input type="checkbox"></span>
                                <div class="tmd_line_inner">
                                    <span>
                                        <img src="../../assets/images/pr_img3.svg" alt="">
                                    </span>
                                    <span>BRAND</span>
                                    <span>78858215</span>
                                    <span>M</span>
                                    <span>7885821511582</span>
                                    <span>artikul_12941529</span>
                                    <span>271 ₽</span>
                                </div>
                            </div>
                            <div class="tmd_line">
                                <span><input type="checkbox"></span>
                                <div class="tmd_line_inner">
                                    <span>
                                        <img src="../../assets/images/pr_img2.svg" alt="">
                                    </span>
                                    <span>BRAND</span>
                                    <span>78858215</span>
                                    <span>S</span>
                                    <span>7885821511582</span>
                                    <span>artikul_12941529</span>
                                    <span>271 ₽</span>
                                </div>
                            </div>
                            <div class="tmd_line">
                                <span><input type="checkbox"></span>
                                <div class="tmd_line_inner">
                                    <span>
                                        <img src="../../assets/images/pr_img.svg" alt="">
                                    </span>
                                    <span>BRAND</span>
                                    <span>78858215</span>
                                    <span>M</span>
                                    <span>7885821511582</span>
                                    <span>artikul_12941529</span>
                                    <span>271 ₽</span>
                                </div>
                            </div>
                            <div class="tmd_line">
                                <span><input type="checkbox"></span>
                                <div class="tmd_line_inner">
                                    <span>
                                        <img src="../../assets/images/pr_img.svg" alt="">
                                    </span>
                                    <span>BRAND</span>
                                    <span>78858215</span>
                                    <span>S</span>
                                    <span>7885821511582</span>
                                    <span>artikul_12941529</span>
                                    <span>271 ₽</span>
                                </div>
                            </div>
                            <div class="tmd_line">
                                <span><input type="checkbox"></span>
                                <div class="tmd_line_inner">
                                    <span>
                                        <img src="../../assets/images/pr_img.svg" alt="">
                                    </span>
                                    <span>BRAND</span>
                                    <span>78858215</span>
                                    <span>S</span>
                                    <span>7885821511582</span>
                                    <span>artikul_12941529</span>
                                    <span>271 ₽</span>
                                </div>
                            </div>
                            <div class="tmd_line">
                                <span><input type="checkbox"></span>
                                <div class="tmd_line_inner">
                                    <span>
                                        <img src="../../assets/images/pr_img.svg" alt="">
                                    </span>
                                    <span>BRAND</span>
                                    <span>78858215</span>
                                    <span>S</span>
                                    <span>7885821511582</span>
                                    <span>artikul_12941529</span>
                                    <span>271 ₽</span>
                                </div>
                            </div>
                            <div class="tmd_line">
                                <span><input type="checkbox"></span>
                                <div class="tmd_line_inner">
                                    <span>
                                        <img src="../../assets/images/pr_img.svg" alt="">
                                    </span>
                                    <span>BRAND</span>
                                    <span>78858215</span>
                                    <span>S</span>
                                    <span>7885821511582</span>
                                    <span>artikul_12941529</span>
                                    <span>271 ₽</span>
                                </div>
                            </div>
                            <div class="tmd_line">
                                <span><input type="checkbox"></span>
                                <div class="tmd_line_inner">
                                    <span>
                                        <img src="../../assets/images/pr_img.svg" alt="">
                                    </span>
                                    <span>BRAND</span>
                                    <span>78858215</span>
                                    <span>S</span>
                                    <span>7885821511582</span>
                                    <span>artikul_12941529</span>
                                    <span>271 ₽</span>
                                </div>
                            </div>
                            <div class="tmd_line">
                                <span><input type="checkbox"></span>
                                <div class="tmd_line_inner">
                                    <span>
                                        <img src="../../assets/images/pr_img.svg" alt="">
                                    </span>
                                    <span>BRAND</span>
                                    <span>78858215</span>
                                    <span>S</span>
                                    <span>7885821511582</span>
                                    <span>artikul_12941529</span>
                                    <span>271 ₽</span>
                                </div>
                            </div>
                            <div class="tmd_line">
                                <span><input type="checkbox"></span>
                                <div class="tmd_line_inner">
                                    <span>
                                        <img src="../../assets/images/pr_img.svg" alt="">
                                    </span>
                                    <span>BRAND</span>
                                    <span>78858215</span>
                                    <span>S</span>
                                    <span>7885821511582</span>
                                    <span>artikul_12941529</span>
                                    <span>271 ₽</span>
                                </div>
                            </div>
                            <div class="tmd_line">
                                <span><input type="checkbox"></span>
                                <div class="tmd_line_inner">
                                    <span>
                                        <img src="../../assets/images/pr_img.svg" alt="">
                                    </span>
                                    <span>BRAND</span>
                                    <span>78858215</span>
                                    <span>S</span>
                                    <span>7885821511582</span>
                                    <span>artikul_12941529</span>
                                    <span>271 ₽</span>
                                </div>
                            </div>
                            <div class="tmd_line">
                                <span><input type="checkbox"></span>
                                <div class="tmd_line_inner">
                                    <span>
                                        <img src="../../assets/images/pr_img.svg" alt="">
                                    </span>
                                    <span>BRAND</span>
                                    <span>78858215</span>
                                    <span>S</span>
                                    <span>7885821511582</span>
                                    <span>artikul_12941529</span>
                                    <span>271 ₽</span>
                                </div>
                            </div>
                            <div class="tmd_line">
                                <span><input type="checkbox"></span>
                                <div class="tmd_line_inner">
                                    <span>
                                        <img src="../../assets/images/pr_img.svg" alt="">
                                    </span>
                                    <span>BRAND</span>
                                    <span>78858215</span>
                                    <span>S</span>
                                    <span>7885821511582</span>
                                    <span>artikul_12941529</span>
                                    <span>271 ₽</span>
                                </div>
                            </div>
                            <div class="tmd_line">
                                <span><input type="checkbox"></span>
                                <div class="tmd_line_inner">
                                    <span>
                                        <img src="../../assets/images/pr_img.svg" alt="">
                                    </span>
                                    <span>BRAND</span>
                                    <span>78858215</span>
                                    <span>S</span>
                                    <span>7885821511582</span>
                                    <span>artikul_12941529</span>
                                    <span>271 ₽</span>
                                </div>
                            </div>
                            <div class="tmd_line">
                                <span><input type="checkbox"></span>
                                <div class="tmd_line_inner">
                                    <span>
                                        <img src="../../assets/images/pr_img.svg" alt="">
                                    </span>
                                    <span>BRAND</span>
                                    <span>78858215</span>
                                    <span>S</span>
                                    <span>7885821511582</span>
                                    <span>artikul_12941529</span>
                                    <span>271 ₽</span>
                                </div>
                            </div>
                            <div class="tmd_line">
                                <span><input type="checkbox"></span>
                                <div class="tmd_line_inner">
                                    <span>
                                        <img src="../../assets/images/pr_img.svg" alt="">
                                    </span>
                                    <span>BRAND</span>
                                    <span>78858215</span>
                                    <span>S</span>
                                    <span>7885821511582</span>
                                    <span>artikul_12941529</span>
                                    <span>271 ₽</span>
                                </div>
                            </div>
                            <div class="tmd_line">
                                <span><input type="checkbox"></span>
                                <div class="tmd_line_inner">
                                    <span>
                                        <img src="../../assets/images/pr_img.svg" alt="">
                                    </span>
                                    <span>BRAND</span>
                                    <span>78858215</span>
                                    <span>S</span>
                                    <span>7885821511582</span>
                                    <span>artikul_12941529</span>
                                    <span>271 ₽</span>
                                </div>
                            </div>
                            <div class="tmd_line">
                                <span><input type="checkbox"></span>
                                <div class="tmd_line_inner">
                                    <span>
                                        <img src="../../assets/images/pr_img.svg" alt="">
                                    </span>
                                    <span>BRAND</span>
                                    <span>78858215</span>
                                    <span>S</span>
                                    <span>7885821511582</span>
                                    <span>artikul_12941529</span>
                                    <span>271 ₽</span>
                                </div>
                            </div>
                            <div class="tmd_line">
                                <span><input type="checkbox"></span>
                                <div class="tmd_line_inner">
                                    <span>
                                        <img src="../../assets/images/pr_img.svg" alt="">
                                    </span>
                                    <span>BRAND</span>
                                    <span>78858215</span>
                                    <span>S</span>
                                    <span>7885821511582</span>
                                    <span>artikul_12941529</span>
                                    <span>271 ₽</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="low_props_md">
                        <div class="low_props_md_inner">
                            <div class="title_md_low">Показать записей</div>
                            <div class="sel_md_low">
                                <select>
                                    <option>10</option>
                                    <option>15</option>
                                    <option>20</option>
                                    <option>25</option>
                                    <option>30</option>
                                </select>
                                <img src="../../assets/images/arr_d.svg" alt="">
                            </div>
                            <div class="pages_md_low">
                                <span>1</span>
                                <span>2</span>
                                <span>3</span>
                                <span>4</span>
                                <span>...</span>
                                <span>10</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</template>