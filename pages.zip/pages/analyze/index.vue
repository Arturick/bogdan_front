<template>
    <div class="md:container md:mx-auto">
        <div class="bg-white rounded-3xl mt-2.5 mx-2.5 p-7 pb-20">
            <div class="l1_sales">
                <NuxtLink to="/">
                    <div class="btn_more_a">Назад</div>
                </NuxtLink>
                <div class="win_title_s">
                    <span>Главная /</span> Анализ товаров
                </div>
            </div>
            <div class="u_titles">
                <div class="u_txt">
                    <div class="u_title">Анализ товара</div>
                    <div class="u_sup">
                        В данном разделе вы можете увидеть  полный анализ<br> своей карточки, сколько ключей, категорий, продаж по<br>  ней, на каких позициях товар
                    </div>
                </div>
            </div>
            <input type="text" class="inp_Ue" placeholder="Поиск по баркоду, артикулу поставщика, бренду"> 
            <div class="table_cont_md">
                <div class="table_new_wrap">
                    <div class="table_md">
                        <div class="tmd_params">
                                    <span>Фото</span>
                                    <span>Бренд</span>
                                    <span>Артикул</span>
                                    <span>Размер</span>
                                    <span>Баркод</span>
                                    <span>Артикул поставщика</span>
                                    <span>Цена WB</span>
                                </div>
                                <div class="tmd_lines">
                                    <div class="tmd_line">
                                        <div class="tmd_line_inner">
                                            <span>
                                                <img src="../../assets/images/pr_img.svg" alt="">
                                            </span>
                                            <span>BRAND</span>
                                            <span>78858215</span>
                                            <span>S</span>
                                            <span>7885821511582</span>
                                            <span>artikul_12941529</span>
                                            <span>271 ₽</span>
                                            <NuxtLink to="/analyze/analyze2" >
                                                <img class="arr_r_ue" src="../../assets/images/arr_r.svg" alt="">
                                            </NuxtLink>
                                        </div>
                                    </div>
                                    <div class="tmd_line">
                                        <div class="tmd_line_inner">
                                            <span>
                                                <img src="../../assets/images/pr_img2.svg" alt="">
                                            </span>
                                            <span>BRAND</span>
                                            <span>78858215</span>
                                            <span>XS</span>
                                            <span>7885821511582</span>
                                            <span>artikul_12941529</span>
                                            <span>271 ₽</span>
                                            <img class="arr_r_ue" src="../../assets/images/arr_r.svg" alt="">
                                        </div>
                                    </div>
                                    <div class="tmd_line">
                                        <div class="tmd_line_inner">
                                            <span>
                                                <img src="../../assets/images/pr_img.svg" alt="">
                                            </span>
                                            <span>BRAND</span>
                                            <span>78858215</span>
                                            <span>L</span>
                                            <span>7885821511582</span>
                                            <span>artikul_12941529</span>
                                            <span>271 ₽</span>
                                            <img class="arr_r_ue" src="../../assets/images/arr_r.svg" alt="">
                                        </div>
                                    </div>
                                    <div class="tmd_line">
                                        <div class="tmd_line_inner">
                                            <span>
                                                <img src="../../assets/images/pr_img3.svg" alt="">
                                            </span>
                                            <span>BRAND</span>
                                            <span>78858215</span>
                                            <span>M</span>
                                            <span>7885821511582</span>
                                            <span>artikul_12941529</span>
                                            <span>271 ₽</span>
                                            <img class="arr_r_ue" src="../../assets/images/arr_r.svg" alt="">
                                        </div>
                                    </div>
                                    <div class="tmd_line">
                                        <div class="tmd_line_inner">
                                            <span>
                                                <img src="../../assets/images/pr_img2.svg" alt="">
                                            </span>
                                            <span>BRAND</span>
                                            <span>78858215</span>
                                            <span>S</span>
                                            <span>7885821511582</span>
                                            <span>artikul_12941529</span>
                                            <span>271 ₽</span>
                                            <img class="arr_r_ue" src="../../assets/images/arr_r.svg" alt=""> 
                                        </div>
                                    </div>
                                    <div class="tmd_line">
                                        <div class="tmd_line_inner">
                                            <span>
                                                <img src="../../assets/images/pr_img.svg" alt="">
                                            </span>
                                            <span>BRAND</span>
                                            <span>78858215</span>
                                            <span>M</span>
                                            <span>7885821511582</span>
                                            <span>artikul_12941529</span>
                                            <span>271 ₽</span>
                                            <img class="arr_r_ue" src="../../assets/images/arr_r.svg" alt=""> 
                                        </div>
                                    </div>
                                    <div class="tmd_line">
                                        <div class="tmd_line_inner">
                                            <span>
                                                <img src="../../assets/images/pr_img.svg" alt="">
                                            </span>
                                            <span>BRAND</span>
                                            <span>78858215</span>
                                            <span>S</span>
                                            <span>7885821511582</span>
                                            <span>artikul_12941529</span>
                                            <span>271 ₽</span>
                                            <img class="arr_r_ue" src="../../assets/images/arr_r.svg" alt=""> 
                                        </div>
                                    </div>
                                    <div class="tmd_line">
                                        <div class="tmd_line_inner">
                                            <span>
                                                <img src="../../assets/images/pr_img.svg" alt="">
                                            </span>
                                            <span>BRAND</span>
                                            <span>78858215</span>
                                            <span>S</span>
                                            <span>7885821511582</span>
                                            <span>artikul_12941529</span>
                                            <span>271 ₽</span>
                                            <img class="arr_r_ue" src="../../assets/images/arr_r.svg" alt=""> 
                                        </div>
                                    </div>
                                    <div class="tmd_line">
                                        <div class="tmd_line_inner">
                                            <span>
                                                <img src="../../assets/images/pr_img.svg" alt="">
                                            </span>
                                            <span>BRAND</span>
                                            <span>78858215</span>
                                            <span>S</span>
                                            <span>7885821511582</span>
                                            <span>artikul_12941529</span>
                                            <span>271 ₽</span>
                                            <img class="arr_r_ue" src="../../assets/images/arr_r.svg" alt=""> 
                                        </div>
                                    </div>
                                    <div class="tmd_line">
                                        <div class="tmd_line_inner">
                                            <span>
                                                <img src="../../assets/images/pr_img.svg" alt="">
                                            </span>
                                            <span>BRAND</span>
                                            <span>78858215</span>
                                            <span>S</span>
                                            <span>7885821511582</span>
                                            <span>artikul_12941529</span>
                                            <span>271 ₽</span>
                                            <img class="arr_r_ue" src="../../assets/images/arr_r.svg" alt=""> 
                                        </div>
                                    </div>
                                    <div class="tmd_line">
                                        <div class="tmd_line_inner">
                                            <span>
                                                <img src="../../assets/images/pr_img.svg" alt="">
                                            </span>
                                            <span>BRAND</span>
                                            <span>78858215</span>
                                            <span>S</span>
                                            <span>7885821511582</span>
                                            <span>artikul_12941529</span>
                                            <span>271 ₽</span>
                                            <img class="arr_r_ue" src="../../assets/images/arr_r.svg" alt=""> 
                                        </div>
                                    </div>
                                    <div class="tmd_line">
                                        <div class="tmd_line_inner">
                                            <span>
                                                <img src="../../assets/images/pr_img.svg" alt="">
                                            </span>
                                            <span>BRAND</span>
                                            <span>78858215</span>
                                            <span>S</span>
                                            <span>7885821511582</span>
                                            <span>artikul_12941529</span>
                                            <span>271 ₽</span>
                                            <img class="arr_r_ue" src="../../assets/images/arr_r.svg" alt=""> 
                                        </div>
                                    </div>
                                    <div class="tmd_line">
                                        <div class="tmd_line_inner">
                                            <span>
                                                <img src="../../assets/images/pr_img.svg" alt="">
                                            </span>
                                            <span>BRAND</span>
                                            <span>78858215</span>
                                            <span>S</span>
                                            <span>7885821511582</span>
                                            <span>artikul_12941529</span>
                                            <span>271 ₽</span>
                                            <img class="arr_r_ue" src="../../assets/images/arr_r.svg" alt=""> 
                                        </div>
                                    </div>
                                    <div class="tmd_line">
                                        <div class="tmd_line_inner">
                                            <span>
                                                <img src="../../assets/images/pr_img.svg" alt="">
                                            </span>
                                            <span>BRAND</span>
                                            <span>78858215</span>
                                            <span>S</span>
                                            <span>7885821511582</span>
                                            <span>artikul_12941529</span>
                                            <span>271 ₽</span>
                                            <img class="arr_r_ue" src="../../assets/images/arr_r.svg" alt=""> 
                                        </div>
                                    </div>
                                    <div class="tmd_line">
                                        <div class="tmd_line_inner">
                                            <span>
                                                <img src="../../assets/images/pr_img.svg" alt="">
                                            </span>
                                            <span>BRAND</span>
                                            <span>78858215</span>
                                            <span>S</span>
                                            <span>7885821511582</span>
                                            <span>artikul_12941529</span>
                                            <span>271 ₽</span>
                                            <img class="arr_r_ue" src="../../assets/images/arr_r.svg" alt=""> 
                                        </div>
                                    </div>
                                    <div class="tmd_line">
                                        <div class="tmd_line_inner">
                                            <span>
                                                <img src="../../assets/images/pr_img.svg" alt="">
                                            </span>
                                            <span>BRAND</span>
                                            <span>78858215</span>
                                            <span>S</span>
                                            <span>7885821511582</span>
                                            <span>artikul_12941529</span>
                                            <span>271 ₽</span>
                                            <img class="arr_r_ue" src="../../assets/images/arr_r.svg" alt=""> 
                                        </div>
                                    </div>
                                    <div class="tmd_line">
                                        <div class="tmd_line_inner">
                                            <span>
                                                <img src="../../assets/images/pr_img.svg" alt="">
                                            </span>
                                            <span>BRAND</span>
                                            <span>78858215</span>
                                            <span>S</span>
                                            <span>7885821511582</span>
                                            <span>artikul_12941529</span>
                                            <span>271 ₽</span>
                                            <img class="arr_r_ue" src="../../assets/images/arr_r.svg" alt=""> 
                                        </div>
                                    </div>
                                    <div class="tmd_line">
                                        <div class="tmd_line_inner">
                                            <span>
                                                <img src="../../assets/images/pr_img.svg" alt="">
                                            </span>
                                            <span>BRAND</span>
                                            <span>78858215</span>
                                            <span>S</span>
                                            <span>7885821511582</span>
                                            <span>artikul_12941529</span>
                                            <span>271 ₽</span>
                                            <img class="arr_r_ue" src="../../assets/images/arr_r.svg" alt=""> 
                                        </div>
                                    </div>
                                    <div class="tmd_line">
                                        <div class="tmd_line_inner">
                                            <span>
                                                <img src="../../assets/images/pr_img.svg" alt="">
                                            </span>
                                            <span>BRAND</span>
                                            <span>78858215</span>
                                            <span>S</span>
                                            <span>7885821511582</span>
                                            <span>artikul_12941529</span>
                                            <span>271 ₽</span>
                                            <img class="arr_r_ue" src="../../assets/images/arr_r.svg" alt=""> 
                                        </div>
                                    </div>
                                    <div class="tmd_line">
                                        <div class="tmd_line_inner">
                                            <span>
                                                <img src="../../assets/images/pr_img.svg" alt="">
                                            </span>
                                            <span>BRAND</span>
                                            <span>78858215</span>
                                            <span>S</span>
                                            <span>7885821511582</span>
                                            <span>artikul_12941529</span>
                                            <span>271 ₽</span>
                                            <img class="arr_r_ue" src="../../assets/images/arr_r.svg" alt=""> 
                                        </div>
                                    </div>
                                    <div class="tmd_line">
                                        <div class="tmd_line_inner">
                                            <span>
                                                <img src="../../assets/images/pr_img.svg" alt="">
                                            </span>
                                            <span>BRAND</span>
                                            <span>78858215</span>
                                            <span>S</span>
                                            <span>7885821511582</span>
                                            <span>artikul_12941529</span>
                                            <span>271 ₽</span>
                                            <img class="arr_r_ue" src="../../assets/images/arr_r.svg" alt=""> 
                                        </div>
                                    </div>
                                    <div class="tmd_line">
                                        <div class="tmd_line_inner">
                                            <span>
                                                <img src="../../assets/images/pr_img.svg" alt="">
                                            </span>
                                            <span>BRAND</span>
                                            <span>78858215</span>
                                            <span>S</span>
                                            <span>7885821511582</span>
                                            <span>artikul_12941529</span>
                                            <span>271 ₽</span>
                                            <img class="arr_r_ue" src="../../assets/images/arr_r.svg" alt=""> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="low_props_md">
                                <div class="low_props_md_inner">
                                    <div class="title_md_low">Показать записей</div>
                                    <div class="sel_md_low">
                                        <select>
                                            <option>10</option>
                                            <option>15</option>
                                            <option>20</option>
                                            <option>25</option>
                                            <option>30</option>
                                        </select>
                                        <img src="../../assets/images/arr_d.svg" alt="">
                                    </div>
                                    <div class="pages_md_low">
                                        <span>1</span>
                                        <span>2</span>
                                        <span>3</span>
                                        <span>4</span>
                                        <span>...</span>
                                        <span>10</span>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
    </div>
</template>